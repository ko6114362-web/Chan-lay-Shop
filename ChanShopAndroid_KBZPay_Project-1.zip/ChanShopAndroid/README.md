# Chan Shop Android starter

မြန်မာဘာသာဖြင့် အထည်ဆိုင်အတွက် Android app starter project ဖြစ်သည်။

## လက်ရှိပါဝင်မှု
- အဖြူ/အပြာရောင် UI နှင့် Chan Shop အမည်
- ပစ္စည်းစာရင်းကြည့်ခြင်း
- ဈေးဝယ်ခြင်းထဲသို့ ထည့်ခြင်း၊ အရေအတွက်ပြောင်းခြင်း
- Admin tab မှ ပစ္စည်းထည့်/ဖျက်ခြင်း
- စုစုပေါင်းကျသင့်ငွေတွက်ချက်ခြင်း

## APK တည်ဆောက်ရန်
1. Android Studio ကိုဖွင့်ပါ။
2. ဒီ project folder ကို Open လုပ်ပါ။
3. Gradle Sync ပြီးအောင်စောင့်ပါ။
4. Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုရွေးပါ။
5. ထွက်လာသော APK ကို ကိုယ့် Android ဖုန်းတွင် install လုပ်နိုင်ပါသည်။

## အရေးကြီးသော ကန့်သတ်ချက်
ဤသည် စတင်အသုံးပြုနိုင်သော prototype ဖြစ်သည်။ လက်ရှိတွင် ပစ္စည်းစာရင်းနှင့် cart သည် app ဖွင့်ထားစဉ် memory ထဲတွင်သာရှိပြီး ဖုန်းပိတ်/ app ပိတ်လျှင် မသိမ်းဆည်းနိုင်ပါ။ Customer အများအပြား၊ online order, login, image upload, payment, delivery tracking တို့အတွက် database နှင့် backend ချိတ်ဆက်ရန် လိုအပ်သည်။ APK ကို ဒီ project မှာ ကြိုတင် compile မလုပ်ထားပါ။


## KBZPay payment display
- User-provided KBZPay QR image is included in the cart screen.
- Displays recipient name Daw Khin Soe Win and phone number 09798636215.
- This is a manual QR payment display only; it does not verify transfers or automatically confirm orders.
